import pygame
import random
import math
import time

# --- Configuration ---
WIDTH, HEIGHT = 1000, 740
BOARD_SIZE = 640
SQ = 80
TUNNEL_CHANCE = 0.3
TUNNEL_ANIM_TIME = 0.35
ENT_BREAK_TIME = 0.55  # quantum burst duration
ENT_DECAY_DIST = 360   # distance threshold for entanglement decay

COLORS = {
    "white_sq": (230, 235, 245),
    "black_sq": (180, 190, 210),
    "white_pc": (0, 150, 255),
    "black_pc": (220, 20, 60),
    "quantum": (0, 100, 255),
    "entangled_near": (255, 140, 0),
    "entangled_far": (150, 80, 255),
    "highlight": (50, 205, 50),
    "sidebar": (240, 242, 245),
    "bg_main": (255, 255, 255),
    "tunnel_wave": (120, 0, 200),
    "burst_inner": (255, 255, 255),
    "burst_outer": (180, 0, 255),
    "preview_move": (0, 200, 120),
    "preview_split": (200, 120, 0),
}

# entanglement break effects
ENT_BREAKS = []

# --- Facts ---
QUANTUM_FACTS = [
    "Quantum brain-scanning helmets now allow imaging while patients move.",
    "Hybrid quantum-classical algorithms are simulating cancer metabolism.",
    "Quantum-secure Q-ID tags prevent fake medicines from entering the lab.",
    "Optical magnetometers detect tiny brain magnetic fields with high precision.",
    "Quantum algorithms are optimizing photodynamic therapy for cancer.",
    "Neutral-atom quantum computers now model complex protein hydration.",
    "Quantum sensing detects biomarkers years before clinical symptoms show.",
    "Redox biology is being mapped at the electronic level via quantum AI.",
    "Quantum-powered 'ghost imaging' sees through tissue with fewer photons.",
    "Atomic clocks ensure super-precise timekeeping for medical logistics.",
    "Quantum machine learning predicts drug toxicity before human trials.",
    "Molecular 'water density' in proteins is now solved by quantum qubits.",
    "Quantum-enhanced MRI provides a step-change in diagnostic sensitivity.",
    "Mitochondrial redox chemistry is a new frontier for quantum medicine.",
    "Quantum sensors in the lab detect single viral particles in real-time.",
    "Biomedical research is shifting to 'quantum-native' molecular modeling.",
    "Quantum error correction ensures patient genetic data remains private.",
    "Lipid Nanoparticles are being optimized using quantum-inspired design.",
    "Quantum tunneling is the primary driver of rapid DNA repair enzymes.",
    "The 2026 quantum medicine field integrates sensing, ML, and computing."
]

SUPERPOSITION_FACTS = [
    "Superposition allows a nanobot to scan two cell clusters at once.",
    "A qubit in superposition represents both 'Infected' and 'Healthy'.",
    "Quantum superposition allows for parallel testing of drug variants.",
    "Biological interference patterns emerge when superposition is stable.",
    "Environmental noise in the blood can destroy fragile superposition.",
    "Quantum computers use superposition to map all protein folds at once.",
    "A superposed electron has no single coordinate until observed.",
    "Superposition is the engine behind quantum biological parallelism.",
    "Quantum states can superpose across multiple cellular energy levels.",
    "Superposition lets a vaccine particle take multiple paths to a virus.",
    "Bio-algorithms rely on controlled superposition for high-speed sync.",
    "Superposition is fragile and easily broken by thermal body heat.",
    "A nanobot's power comes from maintaining a coherent wave state.",
    "Superposition allows quantum scans to outperform classical MRIs.",
    "Quantum waves in a cell add or cancel based on their phase.",
    "Superposition is a measurable physical effect within the Bio-Lab.",
    "Quantum superposition is the foundation of next-gen nanomedicine.",
    "A superposed photon can trigger two different retinal sensors at once.",
    "Superposition breaks when bio-data leaks into the local environment."
]

DECOHERENCE_FACTS = [
    "Decoherence in MRI machines must be minimized for high-res imaging.",
    "Biological decoherence stops proteins from acting like quantum waves.",
    "Fast decoherence in cells forces biology to follow classical laws.",
    "Quantum sensors need shielding from noise to prevent decoherence.",
    "Drug molecules in water decohere into a fixed 3D classical shape.",
    "Decoherence makes blood cells look solid instead of like waves.",
    "Stable coherence in nanobots is vital for targeted drug delivery.",
    "The body's warm environment causes near-instant decoherence.",
    "Bacteria evolved to delay decoherence to move energy efficiently.",
    "Measuring a biomarker forces it into a definite classical state.",
    "Decoherence is why large bio-molecules lose their quantum edge.",
    "Environmental 'noise' in the blood collapses nanobot states.",
    "Coherence must be protected to simulate viral protein folding.",
    "Quantum collapse selects one physical path for a drug molecule.",
    "Thermal energy in tissue is the enemy of quantum coherence.",
    "Decoherence turns quantum probability into medical certainty.",
    "Information leak to the cell environment triggers collapse.",
    "Decoherence explains why we don't see 'ghost' viruses.",
    "Maintaining coherence allows nanobots to scan multiple cells.",
    "Quantum medicine fights decoherence to keep qubits stable."
]

ENTANGLEMENT_FACTS = [
    "Entangled nanobots share data instantly across the bloodstream.",
    "Measuring one entangled viral marker reveals the state of the other.",
    "Entanglement allows for 'ghost imaging' of sensitive biological tissue.",
    "Entangled photons can map deep tissue without damaging cells.",
    "Quantum networks link lab databases via entangled qubit pairs.",
    "Bio-entanglement is stronger than any classical chemical bond.",
    "Bell tests confirm that nanobot sync is truly quantum, not coded.",
    "Entangled qubits simulate complex protein chains as one unit.",
    "Quantum encryption keeps patient genetic data safe from hackers.",
    "Entanglement is used to teleport quantum states between nanobots.",
    "Breaking a bio-link triggers a measurable quantum burst.",
    "Entanglement is the key to error-correcting DNA sequences.",
    "Teleportation in lab chips moves data, not physical matter.",
    "Entangled viral strains behave as a single unified pathogen.",
    "Entanglement entropy helps measure the complexity of a virus.",
    "Quantum links cannot send bio-data faster than the speed of light.",
    "Entangled sensors detect cancer cells with atomic precision.",
    "Entanglement is a critical resource for high-speed vaccine design.",
    "Linked particles bypass classical limits of medical diagnostics."
]

TUNNELING_FACTS = [
    "Quantum tunneling lets nanobots pass through viral cell walls.",
    "Tunneling is the secret behind ultra-fast enzyme reactions.",
    "Proton tunneling allows DNA to mutate during replication.",
    "Quantum tunneling is vital for rapid protein-to-protein signaling.",
    "Nanobots use tunneling to bypass immune system detection.",
    "Tunneling probability increases as the viral barrier thins.",
    "Biological enzymes use tunneling to speed up life-saving chemistry.",
    "Tunneling lets particles 'teleport' through high-energy barriers.",
    "Scanning microscopes use tunneling to map the Spike Protein.",
    "Tunneling is impossible in classical physics, but common in cells.",
    "Lighter particles, like protons, tunnel more easily in tissue.",
    "Quantum tunneling drives the chemical bonds in mRNA strands.",
    "Viral mutations can occur when atoms tunnel to the wrong place.",
    "Superconducting lab chips use tunneling to process bio-data.",
    "Tunneling currents reveal the atomic structure of a virus.",
    "Cells use tunneling to move electrons across long distances.",
    "Particles tunnel even without the energy to climb over barriers.",
    "Quantum tunneling shapes the way drugs bind to cell receptors.",
    "In stars and cells alike, tunneling makes the 'impossible' happen.",
    "Nanobot sensors rely on tunneling to detect single biomarkers."
]


# =========================
#   PIECE CLASS
# =========================
class Piece:
    def __init__(self, name, r, c, color):
        self.name, self.r, self.c, self.color = name, r, c, color
        self.is_superposed = False
        self.states = []          # list of (r, c)
        self.entangled_with = None  # single link; chains via graph traversal
        try:
            img_path = f"assets/{self.color}_{self.name}.png"
            self.image = pygame.image.load(img_path).convert_alpha()
            self.image = pygame.transform.scale(self.image, (SQ, SQ))
        except:
            self.image = None

    def is_legal_move(self, tr, tc, pieces):
        if self.is_superposed:
            return False
        dr, dc = tr - self.r, tc - self.c
        abs_dr, abs_dc = abs(dr), abs(dc)

        if self.name == "P":
            direction = -1 if self.color == 'W' else 1
            if dc == 0 and dr == direction:
                return not self.is_occ(tr, tc, pieces)
            if dc == 0 and dr == 2 * direction and (
                (self.r == 6 and self.color == 'W') or (self.r == 1 and self.color == 'B')
            ):
                return not self.is_occ(tr, tc, pieces) and not self.is_occ(self.r + direction, tc, pieces)
            if abs_dc == 1 and dr == direction:
                return self.is_occ(tr, tc, pieces)
            return False

        if self.name in ["R", "B", "Q"]:
            if self.name == "R":
                return dr == 0 or dc == 0
            if self.name == "B":
                return abs_dr == abs_dc
            return dr == 0 or dc == 0 or abs_dr == abs_dc

        if self.name == "N":
            return (abs_dr == 2 and abs_dc == 1) or (abs_dr == 1 and abs_dc == 2)

        if self.name == "K":
            return abs_dr <= 1 and abs_dc <= 1

        return False

    def is_occ(self, r, c, pieces):
        return any(
            (not p.is_superposed and p.r == r and p.c == c) or
            (p.is_superposed and (r, c) in p.states)
            for p in pieces
        )

    def path_blocked(self, tr, tc, pieces):
        if self.name == "N" or self.is_superposed:
            return False
        sr = 0 if tr == self.r else (1 if tr > self.r else -1)
        sc = 0 if tc == self.c else (1 if tc > self.c else -1)
        cr, cc = self.r + sr, self.c + sc
        while cr != tr or cc != tc:
            if any((not p.is_superposed) and p.r == cr and p.c == cc for p in pieces):
                return True
            cr += sr
            cc += sc
        return False

    def move(self, r, c):
        self.r, self.c = r, c
        self.is_superposed = False
        self.states = []

    def superpose(self, p1, p2):
        self.states = [p1, p2]
        self.is_superposed = True
        self.r, self.c = None, None

    def add_branch(self, r, c):
        if not self.is_superposed:
            self.is_superposed = True
            self.states = [(self.r, self.c), (r, c)]
            self.r = None
            self.c = None
        else:
            if (r, c) not in self.states:
                self.states.append((r, c))

    def collapse(self):
        # collapse entire entangled cluster (chains, GHZ)
        collapse_entangled_cluster(self)


# =========================
#   HELPERS
# =========================
def get_piece_at(pieces, r, c, include_superposed=False):
    for p in pieces:
        if not include_superposed and p.is_superposed:
            continue
        if not p.is_superposed and p.r == r and p.c == c:
            return p
        if include_superposed and p.is_superposed and (r, c) in p.states:
            return p
    return None


def get_position_for_render(p):
    if p.is_superposed and p.states:
        r, c = p.states[0]
        return r, c
    return p.r, p.c


def get_entangled_cluster(start):
    visited = set()
    stack = [start]
    cluster = []
    while stack:
        p = stack.pop()
        if id(p) in visited:
            continue
        visited.add(id(p))
        cluster.append(p)
        if p.entangled_with and id(p.entangled_with) not in visited:
            stack.append(p.entangled_with)
    return cluster


def collapse_entangled_cluster(start):
    global ENT_BREAKS
    cluster = get_entangled_cluster(start)

    # choose a branch index for correlation if possible
    # use the first superposed piece as reference
    ref = next((p for p in cluster if p.is_superposed and p.states), None)
    if ref:
        k = random.randrange(len(ref.states))
    else:
        k = 0

    # collapse all in cluster
    for p in cluster:
        if p.is_superposed and p.states:
            idx = min(k, len(p.states) - 1)
            fr, fc = p.states[idx]
            p.r, p.c = fr, fc
            p.states = []
            p.is_superposed = False

    # create burst effects between all pairs in cluster
    for i in range(len(cluster)):
        for j in range(i + 1, len(cluster)):
            a = cluster[i]
            b = cluster[j]
            ar, ac = get_position_for_render(a)
            br, bc = get_position_for_render(b)
            ax = ac * SQ + SQ // 2
            ay = ar * SQ + SQ // 2
            bx = bc * SQ + SQ // 2
            by = br * SQ + SQ // 2
            ENT_BREAKS.append({"ax": ax, "ay": ay, "bx": bx, "by": by, "start": time.time()})

    # clear entanglement links
    for p in cluster:
        p.entangled_with = None


# =========================
#   SIDEBAR
# =========================
def draw_sidebar(screen, turn, research, pieces, fact_index, quantum_event):
    pygame.draw.rect(screen, COLORS["sidebar"], (BOARD_SIZE, 0, WIDTH - BOARD_SIZE, HEIGHT))

    header_f = pygame.font.SysFont("Arial", 22, bold=True)
    stats_f = pygame.font.SysFont("Arial", 16, bold=True)
    body_f = pygame.font.SysFont("Arial", 15)

    x, y = BOARD_SIZE + 20, 30

    status_color = COLORS["white_pc"] if turn == 'W' else COLORS["black_pc"]
    pygame.draw.rect(screen, (220, 225, 235), (x-10, y-10, 320, 70), border_radius=10)
    status_text = "NANOBOT TURN" if turn == 'W' else "VIRAL MUTATION"
    screen.blit(header_f.render(status_text, True, status_color), (x+10, y+10))

    if quantum_event == "superposition":
        fact = SUPERPOSITION_FACTS[fact_index % len(SUPERPOSITION_FACTS)]
    elif quantum_event == "collapse":
        fact = DECOHERENCE_FACTS[fact_index % len(DECOHERENCE_FACTS)]
    elif quantum_event == "entanglement":
        fact = ENTANGLEMENT_FACTS[fact_index % len(ENTANGLEMENT_FACTS)]
    elif quantum_event == "tunneling":
        fact = TUNNELING_FACTS[fact_index % len(TUNNELING_FACTS)]
    else:
        fact = QUANTUM_FACTS[fact_index % len(QUANTUM_FACTS)]

    y += 90
    white_count = sum(1 for p in pieces if p.color == 'W')
    black_count = sum(1 for p in pieces if p.color == 'B')
    screen.blit(header_f.render("BIO-SCANNER", True, (50, 50, 50)), (x, y))
    pygame.draw.line(screen, (150, 150, 160), (x, y+35), (WIDTH-20, y+35), 3)
    screen.blit(stats_f.render(f"Nanobots: {white_count}", True, COLORS["white_pc"]), (x, y + 50))
    screen.blit(stats_f.render(f"Viral Strains: {black_count}", True, COLORS["black_pc"]), (x, y + 75))

    y += 130
    screen.blit(header_f.render("VACCINE PROGRESS", True, (0, 100, 200)), (x, y))
    labs = [
        ("Drug Discovery", research['med'], (0, 150, 255)),
        ("Biomass Removal", research['cli'], (50, 200, 50)),
        ("Quantum Sync", research['cyb'], (255, 50, 50)),
    ]
    y_bar = y + 40
    for label, val, col in labs:
        screen.blit(stats_f.render(label, True, (80, 80, 80)), (x, y_bar))
        pygame.draw.rect(screen, (200, 205, 215), (x, y_bar + 25, 200, 15), border_radius=5)
        fill_w = int((val / 100) * 200)
        if fill_w > 0:
            pygame.draw.rect(screen, col, (x, y_bar + 25, fill_w, 15), border_radius=5)
        y_bar += 65

    y_fact = 520
    pygame.draw.rect(screen, (255, 255, 255), (x-5, y_fact, 330, 120), border_radius=12)
    pygame.draw.rect(screen, (0, 150, 255), (x-5, y_fact, 330, 120), 2, border_radius=12)

    screen.blit(stats_f.render("QUBIT INSIGHT:", True, (0, 120, 200)), (x+10, y_fact+10))

    words = fact.split(' ')
    l1, l2, l3 = "", "", ""
    for w in words:
        if len(l1) + len(w) < 32:
            l1 += w + " "
        elif len(l2) + len(w) < 32:
            l2 += w + " "
        else:
            l3 += w + " "

    screen.blit(body_f.render(l1, True, (60, 60, 60)), (x+10, y_fact+40))
    screen.blit(body_f.render(l2, True, (60, 60, 60)), (x+10, y_fact+65))
    screen.blit(body_f.render(l3, True, (60, 60, 60)), (x+10, y_fact+90))

    screen.blit(stats_f.render("[S] Split  [Z] Cancel  [R] Restart  [U] Undo", True, (120, 120, 120)), (x, 705))
    # No visual Undo button anymore; just the text hint.


def draw_victory_screen(screen, winner, research):
    overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
    overlay.fill((255, 255, 255, 230))
    screen.blit(overlay, (0, 0))

    font_lg = pygame.font.SysFont("Arial", 55, bold=True)
    font_sm = pygame.font.SysFont("Arial", 24, bold=True)

    if winner == "WHITE":
        title, color, msg = "MISSION SUCCESS", (0, 180, 200), "Vaccine synthesized and deployed."
    else:
        title, color, msg = "MISSION FAILED", (220, 20, 60), "The viral strain has mutated too far."

    txt = font_lg.render(title, True, color)
    screen.blit(txt, (WIDTH//2 - txt.get_width()//2, HEIGHT//2 - 100))

    sub_txt = font_sm.render(msg, True, (50, 50, 50))
    screen.blit(sub_txt, (WIDTH//2 - sub_txt.get_width()//2, HEIGHT//2 - 20))

    total_res = (research['med'] + research['cli'] + research['cyb']) // 3
    res_txt = font_sm.render(f"Global Impact Score: {total_res}%", True, (0, 100, 200))
    screen.blit(res_txt, (WIDTH//2 - res_txt.get_width()//2, HEIGHT//2 + 40))

    restart_txt = font_sm.render("Press 'R' to Restart Simulation", True, (100, 100, 100))
    screen.blit(restart_txt, (WIDTH//2 - restart_txt.get_width()//2, HEIGHT//2 + 120))


# =========================
#   BOARD CREATION
# =========================
def create_board():
    pieces = []
    layout = ["R", "N", "B", "Q", "K", "B", "N", "R"]
    for c, name in enumerate(layout):
        pieces.append(Piece(name, 0, c, 'B'))
        pieces.append(Piece("P", 1, c, 'B'))
        pieces.append(Piece(name, 7, c, 'W'))
        pieces.append(Piece("P", 6, c, 'W'))
    return pieces


# =========================
#   STATE SNAPSHOT FOR UNDO
# =========================
def clone_piece(p):
    return {
        "name": p.name,
        "r": p.r,
        "c": p.c,
        "color": p.color,
        "is_superposed": p.is_superposed,
        "states": list(p.states),
        "entangled_with": None,
    }


def restore_piece(data):
    p = Piece(data["name"], data["r"], data["c"], data["color"])
    p.is_superposed = data["is_superposed"]
    p.states = list(data["states"])
    return p


def save_state(pieces, turn, split_mode, game_over, winner, fact_index,
               research, quantum_event, tunneling_active, tunneling_start_time,
               tunneling_pos):
    global ENT_BREAKS

    pcs = [clone_piece(p) for p in pieces]

    ent_map = {}
    for i, p in enumerate(pieces):
        if p.entangled_with:
            j = pieces.index(p.entangled_with)
            ent_map[i] = j

    return {
        "pieces": pcs,
        "ent_map": ent_map,
        "turn": turn,
        "split_mode": split_mode,
        "game_over": game_over,
        "winner": winner,
        "fact_index": fact_index,
        "research": research.copy(),
        "quantum_event": quantum_event,
        "tunneling_active": tunneling_active,
        "tunneling_start_time": tunneling_start_time,
        "tunneling_pos": tunneling_pos,
        "ENT_BREAKS": [dict(e) for e in ENT_BREAKS],
    }


def load_state(state):
    global ENT_BREAKS

    pieces = [restore_piece(p) for p in state["pieces"]]

    for i, j in state["ent_map"].items():
        pieces[i].entangled_with = pieces[j]

    ENT_BREAKS = [dict(e) for e in state["ENT_BREAKS"]]

    return (
        pieces,
        state["turn"],
        state["split_mode"],
        state["game_over"],
        state["winner"],
        state["fact_index"],
        state["research"],
        state["quantum_event"],
        state["tunneling_active"],
        state["tunneling_start_time"],
        state["tunneling_pos"],
    )


# =========================
#   MAIN LOOP
# =========================
def main():
    global ENT_BREAKS
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Quantum Bio-Lab")

    pieces = create_board()
    selected = None
    turn = 'W'
    split_mode = False
    game_over = False
    winner = None
    fact_index = 0
    research = {'med': 0, 'cli': 0, 'cyb': 0}
    quantum_event = None

    tunneling_active = False
    tunneling_start_time = 0
    tunneling_pos = None

    history = []

    clock = pygame.time.Clock()

    while True:
        clock.tick(60)
        screen.fill(COLORS["bg_main"])

        # Board rendering
        for r in range(8):
            for c in range(8):
                col = COLORS["white_sq"] if (r + c) % 2 == 0 else COLORS["black_sq"]
                pygame.draw.rect(screen, col, (c * SQ, r * SQ, SQ, SQ))

        draw_sidebar(screen, turn, research, pieces, fact_index, quantum_event)

        # Pieces + superposition glow
        for p in pieces:
            if p.is_superposed:
                for sr, sc in p.states:
                    center = (sc * SQ + SQ // 2, sr * SQ + SQ // 2)
                    for radius in range(38, 48, 4):
                        surf = pygame.Surface((radius * 2, radius * 2), pygame.SRCALPHA)
                        pygame.draw.circle(surf, (0, 180, 255, 40), (radius, radius), radius, 1)
                        screen.blit(surf, (center[0] - radius, center[1] - radius))

                for sr, sc in p.states:
                    if p.image:
                        g = p.image.copy()
                        g.set_alpha(120)
                        screen.blit(g, (sc * SQ, sr * SQ))
                    pygame.draw.rect(screen, COLORS["quantum"], (sc * SQ, sr * SQ, SQ, SQ), 3)
            else:
                if p.image:
                    screen.blit(p.image, (p.c * SQ, p.r * SQ))

            if p == selected and not p.is_superposed:
                pygame.draw.rect(screen, COLORS["highlight"], (p.c * SQ, p.r * SQ, SQ, SQ), 4)

        # Move preview (normal moves) – square animation
        if selected and not selected.is_superposed and not game_over and not split_mode:
            for r in range(8):
                for c in range(8):
                    if r == selected.r and c == selected.c:
                        continue
                    if not selected.is_legal_move(r, c, pieces):
                        continue
                    if selected.name != "N" and selected.path_blocked(r, c, pieces):
                        continue
                    target = get_piece_at(pieces, r, c, include_superposed=False)
                    if target and target.color == selected.color:
                        continue
                    surf = pygame.Surface((SQ, SQ), pygame.SRCALPHA)
                    pygame.draw.rect(
                        surf,
                        (*COLORS["preview_move"], 80),
                        (6, 6, SQ - 12, SQ - 12),
                        3
                    )
                    screen.blit(surf, (c * SQ, r * SQ))

        # Move preview (split mode) – square animation
        if split_mode and selected and not selected.is_superposed and not game_over:
            for r in range(8):
                for c in range(8):
                    if r == selected.r and c == selected.c:
                        continue
                    if not selected.is_legal_move(r, c, pieces):
                        continue
                    if selected.name != "N" and selected.path_blocked(r, c, pieces):
                        continue
                    target = get_piece_at(pieces, r, c, include_superposed=False)
                    if target and target.color == selected.color:
                        continue
                    surf = pygame.Surface((SQ, SQ), pygame.SRCALPHA)
                    pygame.draw.rect(
                        surf,
                        (*COLORS["preview_split"], 80),
                        (6, 6, SQ - 12, SQ - 12),
                        3
                    )
                    screen.blit(surf, (c * SQ, r * SQ))

        # Entanglement lines – simplified, single clear line
        drawn_pairs = set()
        for p in pieces:
            if p.entangled_with and p.entangled_with in pieces:
                a = p
                b = p.entangled_with
                if (id(a), id(b)) in drawn_pairs or (id(b), id(a)) in drawn_pairs:
                    continue
                drawn_pairs.add((id(a), id(b)))

                ar, ac = get_position_for_render(a)
                br, bc = get_position_for_render(b)

                ax = ac * SQ + SQ // 2
                ay = ar * SQ + SQ // 2
                bx = bc * SQ + SQ // 2
                by = br * SQ + SQ // 2

                # fixed, bright color and width so it's obvious
                line_color = COLORS["entangled_near"]
                pygame.draw.line(screen, line_color, (ax, ay), (bx, by), 4)

                # small endpoint dots to show which pieces are linked
                pygame.draw.circle(screen, line_color, (ax, ay), 6, 2)
                pygame.draw.circle(screen, line_color, (bx, by), 6, 2)

        # Entanglement decay by distance
        for p in pieces:
            q = p.entangled_with
            if not q or q not in pieces:
                continue
            pr, pc = get_position_for_render(p)
            qr, qc = get_position_for_render(q)
            px = pc * SQ + SQ // 2
            py = pr * SQ + SQ // 2
            qx = qc * SQ + SQ // 2
            qy = qr * SQ + SQ // 2
            d = math.hypot(qx - px, qy - py)
            if d > ENT_DECAY_DIST:
                ENT_BREAKS.append({"ax": px, "ay": py, "bx": qx, "by": qy, "start": time.time()})
                p.entangled_with = None
                q.entangled_with = None

        # Entanglement break animations
        new_breaks = []
        for eff in ENT_BREAKS:
            elapsed = time.time() - eff["start"]
            if elapsed > ENT_BREAK_TIME:
                continue
            progress = elapsed / ENT_BREAK_TIME

            alpha_line = int(255 * (1 - progress))
            line_width = int(6 * (1 - progress) + 1)
            line_surf = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
            line_color = (255, 230, 180, alpha_line)
            pygame.draw.line(line_surf, line_color, (eff["ax"], eff["ay"]), (eff["bx"], eff["by"]), line_width)
            screen.blit(line_surf, (0, 0))

            mx = (eff["ax"] + eff["bx"]) // 2
            my = (eff["ay"] + eff["by"]) // 2
            radius = int(10 + 50 * progress)
            alpha_ring = int(255 * (1 - progress))
            ring_surf = pygame.Surface((radius * 2, radius * 2), pygame.SRCALPHA)
            inner = COLORS["burst_inner"]
            outer = COLORS["burst_outer"]
            col = (
                int(inner[0] * (1 - progress) + outer[0] * progress),
                int(inner[1] * (1 - progress) + outer[1] * progress),
                int(inner[2] * (1 - progress) + outer[2] * progress),
                alpha_ring,
            )
            pygame.draw.circle(ring_surf, col, (radius, radius), radius, 3)
            screen.blit(ring_surf, (mx - radius, my - radius))

            new_breaks.append(eff)
        ENT_BREAKS = new_breaks

        # Tunneling animation
        if tunneling_active and tunneling_pos is not None:
            elapsed = time.time() - tunneling_start_time
            if elapsed > TUNNEL_ANIM_TIME:
                tunneling_active = False
            else:
                progress = elapsed / TUNNEL_ANIM_TIME
                radius = int(20 + 40 * progress)
                alpha = int(200 * (1 - progress))
                surf = pygame.Surface((radius * 2, radius * 2), pygame.SRCALPHA)
                pygame.draw.circle(surf, (*COLORS["tunnel_wave"], alpha), (radius, radius), radius, 3)
                screen.blit(surf, (tunneling_pos[0] - radius, tunneling_pos[1] - radius))

        if game_over:
            draw_victory_screen(screen, winner, research)

        # Event Handling
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_r:
                    main()
                if event.key == pygame.K_u:
                    if history:
                        state = history.pop()
                        (pieces, turn, split_mode, game_over, winner, fact_index,
                         research, quantum_event, tunneling_active,
                         tunneling_start_time, tunneling_pos) = load_state(state)
                        selected = None
                    continue
                if game_over:
                    continue
                if event.key == pygame.K_z:
                    selected = None
                    split_mode = False
                if event.key == pygame.K_s and selected and not selected.is_superposed:
                    split_mode = True

            if not game_over and event.type == pygame.MOUSEBUTTONDOWN:
                pos = pygame.mouse.get_pos()

                c, r = pos[0] // SQ, pos[1] // SQ
                if c >= 8 or r >= 8:
                    continue

                ghost = next((p for p in pieces if p.is_superposed and (r, c) in p.states), None)

                if ghost and ghost.name == "K":
                    history.append(save_state(pieces, turn, split_mode, game_over, winner,
                                              fact_index, research, quantum_event,
                                              tunneling_active, tunneling_start_time,
                                              tunneling_pos))
                    game_over = True
                    winner = "WHITE" if turn == 'W' else "BLACK"
                    continue

                if selected and ghost and selected != ghost:
                    if selected.is_legal_move(r, c, pieces):
                        history.append(save_state(pieces, turn, split_mode, game_over, winner,
                                                  fact_index, research, quantum_event,
                                                  tunneling_active, tunneling_start_time,
                                                  tunneling_pos))
                        # entangle selected with ghost (multi-branch cluster via graph)
                        selected.entangled_with = ghost
                        ghost.entangled_with = selected
                        sr, sc = selected.r, selected.c
                        selected.superpose((sr, sc), (r, c))
                        research['cyb'] += 20
                        quantum_event = "entanglement"
                        selected = None
                        turn = 'B' if turn == 'W' else 'W'
                        fact_index += 1
                        continue

                elif ghost:
                    history.append(save_state(pieces, turn, split_mode, game_over, winner,
                                              fact_index, research, quantum_event,
                                              tunneling_active, tunneling_start_time,
                                              tunneling_pos))
                    ghost.collapse()
                    quantum_event = "collapse"
                    fact_index += 1
                    continue

                clicked = next((p for p in pieces if not p.is_superposed and p.r == r and p.c == c), None)

                if split_mode and selected and selected.is_legal_move(r, c, pieces):
                    if selected.name != "N" and selected.path_blocked(r, c, pieces):
                        continue
                    target = get_piece_at(pieces, r, c, include_superposed=False)
                    if target and target.color == selected.color:
                        continue
                    history.append(save_state(pieces, turn, split_mode, game_over, winner,
                                              fact_index, research, quantum_event,
                                              tunneling_active, tunneling_start_time,
                                              tunneling_pos))
                    selected.add_branch(r, c)
                    research['med'] += 15
                    quantum_event = "superposition"
                    split_mode = False
                    selected = None
                    turn = 'B' if turn == 'W' else 'W'
                    fact_index += 1

                elif clicked and clicked.color == turn:
                    selected = clicked

                elif selected and not selected.is_superposed and selected.is_legal_move(r, c, pieces):
                    can_move = True

                    if selected.name != "N" and selected.path_blocked(r, c, pieces):
                        quantum_field_active = any(p.is_superposed for p in pieces)

                        if quantum_field_active and selected.name == "B" and random.random() < TUNNEL_CHANCE:
                            history.append(save_state(pieces, turn, split_mode, game_over, winner,
                                                      fact_index, research, quantum_event,
                                                      tunneling_active, tunneling_start_time,
                                                      tunneling_pos))
                            research['cli'] += 25
                            quantum_event = "tunneling"
                            tunneling_active = True
                            tunneling_start_time = time.time()
                            tunneling_pos = (selected.c * SQ + SQ // 2, selected.r * SQ + SQ // 2)
                        else:
                            can_move = False

                    if can_move:
                        if not tunneling_active:
                            history.append(save_state(pieces, turn, split_mode, game_over, winner,
                                                      fact_index, research, quantum_event,
                                                      tunneling_active, tunneling_start_time,
                                                      tunneling_pos))

                        target = next((p for p in pieces if not p.is_superposed and p.r == r and p.c == c), None)

                        # entanglement swapping: attacker and target both entangled
                        if target and target.entangled_with and selected.entangled_with and \
                           target.entangled_with is not selected and selected.entangled_with is not target:
                            a_partner = selected.entangled_with
                            b_partner = target.entangled_with
                            a_partner.entangled_with = b_partner
                            b_partner.entangled_with = a_partner
                            selected.entangled_with = None
                            target.entangled_with = None

                        if target and target.name == "K":
                            game_over = True
                            winner = "WHITE" if turn == 'W' else "BLACK"

                        if target:
                            if target.entangled_with:
                                collapse_entangled_cluster(target)
                            if target in pieces:
                                pieces.remove(target)
                            research['cli'] += 10

                        selected.move(r, c)
                        if not tunneling_active:
                            quantum_event = None
                        selected = None
                        turn = 'B' if turn == 'W' else 'W'
                        fact_index += 1

        pygame.display.flip()


if __name__ == "__main__":
    main()

import pygame
import random
import math

# --- Configuration ---
WIDTH, HEIGHT = 1000, 740
BOARD_SIZE = 640
SQ = 80
TUNNEL_CHANCE = 0.3
COLORS = {
    "white_sq": (245, 245, 220), "black_sq": (110, 140, 70),
    "white_pc": (255, 255, 255), "black_pc": (20, 20, 20),
    "quantum": (0, 150, 255), "entangled": (255, 50, 50),
    "highlight": (255, 215, 0), "sidebar": (25, 25, 35)
}

# --- Educational Database ---
QUANTUM_FACTS = [
    "Quantum Computers use Qubits, not Bits.",
    "Particles can be in two places at once.",
    "Observation changes the outcome of reality.",
    "Entanglement works across the entire universe.",
    "MRI machines use the 'spin' of atoms.",
    "Flash drives work because of Electron Tunneling.",
    "Lasers are a result of quantum transitions.",
    "Atomic clocks are used for GPS navigation.",
    "Quantum sensors can detect underground oil.",
    "Photosynthesis may use quantum effects!",
    "Superconductors have zero electrical resistance.",
    "Quantum cryptography is unhackable.",
    "The 'Double Slit' experiment proved wave-duality."
]

class Piece:
    def __init__(self, name, r, c, color):
        self.name, self.r, self.c, self.color = name, r, c, color
        self.is_superposed, self.states, self.entangled_with = False, [], None
        img_path = f"assets/{self.color}_{self.name}.png"
        try:
            self.image = pygame.image.load(img_path).convert_alpha()
            self.image = pygame.transform.scale(self.image, (SQ, SQ))
        except:
            self.image = None

    def is_legal_move(self, tr, tc, pieces):
        dr, dc = tr - self.r, tc - self.c
        abs_dr, abs_dc = abs(dr), abs(dc)
        if self.name == "P":
            dir = -1 if self.color == 'W' else 1
            if dc == 0 and dr == dir: return not self.is_occ(tr, tc, pieces)
            if dc == 0 and dr == 2*dir and ((self.r==6 and self.color=='W') or (self.r==1 and self.color=='B')):
                return not self.is_occ(tr, tc, pieces) and not self.is_occ(self.r+dir, tc, pieces)
            if abs_dc == 1 and dr == dir: return self.is_occ(tr, tc, pieces)
            return False
        if self.name in ["R", "B", "Q"]:
            ok = (dr==0 or dc==0) if self.name=="R" else (abs_dr==abs_dc) if self.name=="B" else (dr==0 or dc==0 or abs_dr==abs_dc)
            return ok 
        if self.name == "N": return (abs_dr==2 and abs_dc==1) or (abs_dr==1 and abs_dc==2)
        if self.name == "K": return abs_dr<=1 and abs_dc<=1
        return False

    def is_occ(self, r, c, pieces):
        return any(not p.is_superposed and p.r == r and p.c == c for p in pieces)

    def path_blocked(self, tr, tc, pieces):
        if self.name == "N": return False 
        sr = 0 if tr == self.r else (1 if tr > self.r else -1)
        sc = 0 if tc == self.c else (1 if tc > self.c else -1)
        cr, cc = self.r + sr, self.c + sc
        while cr != tr or cc != tc:
            if self.is_occ(cr, cc, pieces): return True
            cr += sr; cc += sc
        return False

    def move(self, r, c):
        self.r, self.c, self.is_superposed, self.states = r, c, False, []

    def superpose(self, p1, p2):
        self.states, self.is_superposed = [p1, p2], True

    def collapse(self):
        if self.is_superposed:
            final = random.choice(self.states)
            self.move(final[0], final[1])
            if self.entangled_with and self.entangled_with.is_superposed:
                partner = self.entangled_with
                self.entangled_with = partner.entangled_with = None
                partner.collapse()

def draw_sidebar(screen, turn, split_mode, fact_index, pieces):
    pygame.draw.rect(screen, COLORS["sidebar"], (BOARD_SIZE, 0, WIDTH - BOARD_SIZE, HEIGHT))
    header_f = pygame.font.SysFont("Verdana", 18, bold=True)
    body_f = pygame.font.SysFont("Verdana", 14)
    small_f = pygame.font.SysFont("Verdana", 12, italic=True)
    
    x, y = BOARD_SIZE + 20, 20

    # 1. TURN STATUS
    pygame.draw.rect(screen, (40, 40, 60), (x-10, y-10, 320, 55), border_radius=5)
    turn_text = "WHITE TO MOVE" if turn == 'W' else "BLACK TO MOVE"
    screen.blit(header_f.render(turn_text, True, (255, 255, 255)), (x, y))
    mode_txt = "QUANTUM MODE" if split_mode else "CLASSICAL MODE"
    screen.blit(body_f.render(mode_txt, True, (100, 255, 100)), (x, y + 25))

    # 2. PIECE COUNTER (NEW)
    y += 75
    screen.blit(header_f.render("PIECES REMAINING", True, (255, 255, 255)), (x, y))
    w_left = sum(1 for p in pieces if p.color == 'W')
    b_left = sum(1 for p in pieces if p.color == 'B')
    
    # Draw simple bars for visual effect
    screen.blit(body_f.render(f"White: {w_left} / 16", True, (230, 230, 230)), (x, y + 25))
    screen.blit(body_f.render(f"Black: {b_left} / 16", True, (180, 180, 180)), (x, y + 45))

    # 3. THE HANDBOOK
    y += 90
    screen.blit(header_f.render("QUANTUM LAWS", True, COLORS["highlight"]), (x, y))
    lessons = [
        ("SUPERPOSITION", "A piece exists in 2 spots."),
        ("ENTANGLEMENT", "Linked pieces share a fate."),
        ("TUNNELING", "Probability to bypass walls."),
        ("COLLAPSE", "Observation creates reality.")
    ]
    for title, desc in lessons:
        y += 40
        screen.blit(body_f.render(title, True, COLORS["quantum"]), (x, y))
        screen.blit(small_f.render(desc, True, (180, 180, 180)), (x, y + 18))

    # 4. DYNAMIC DID YOU KNOW?
    y += 100
    pygame.draw.line(screen, (100, 100, 100), (x, y), (WIDTH-20, y), 2)
    y += 20
    screen.blit(header_f.render("DID YOU KNOW?", True, (255, 100, 100)), (x, y))
    
    current_fact = QUANTUM_FACTS[fact_index % len(QUANTUM_FACTS)]
    words = current_fact.split(' ')
    line1, line2 = "", ""
    for word in words:
        if len(line1 + word) < 25: line1 += word + " "
        else: line2 += word + " "
    screen.blit(body_f.render(line1, True, (255, 255, 255)), (x, y + 35))
    screen.blit(body_f.render(line2, True, (255, 255, 255)), (x, y + 55))

    # 5. FOOTER
    pygame.draw.rect(screen, (0, 100, 200), (BOARD_SIZE+10, HEIGHT-60, 320, 45), border_radius=8)
    screen.blit(body_f.render("Quantum Tech: Saving the Planet", True, (255, 255, 255)), (x+10, HEIGHT-48))

def draw_win_screen(screen, winner):
    overlay = pygame.Surface((WIDTH, HEIGHT))
    overlay.set_alpha(230); overlay.fill((0, 0, 0))
    screen.blit(overlay, (0, 0))
    font = pygame.font.SysFont("Arial", 64, bold=True)
    win_txt = font.render(f"{winner} WINS!", True, (255, 215, 0))
    screen.blit(win_txt, win_txt.get_rect(center=(WIDTH//2, HEIGHT//2)))

def create_board():
    pieces = []
    layout = ["R", "N", "B", "Q", "K", "B", "N", "R"]
    for c, name in enumerate(layout):
        pieces.append(Piece(name, 0, c, 'B'))
        pieces.append(Piece("P", 1, c, 'B'))
        pieces.append(Piece(name, 7, c, 'W'))
        pieces.append(Piece("P", 6, c, 'W'))
    return pieces

def main():
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Quantum Chess EDU")
    pieces = create_board()
    selected, turn, split_mode = None, 'W', False
    game_over, winner = False, None
    fact_index = 0 

    while True:
        screen.fill((20, 20, 20))
        for r in range(8):
            for c in range(8):
                col = COLORS["white_sq"] if (r+c)%2==0 else COLORS["black_sq"]
                pygame.draw.rect(screen, col, (c*SQ, r*SQ, SQ, SQ))
        
        draw_sidebar(screen, turn, split_mode, fact_index, pieces)

        for p in pieces:
            if p.is_superposed:
                d_col = COLORS["entangled"] if p.entangled_with else COLORS["quantum"]
                for sr, sc in p.states:
                    if p.image:
                        ghost = p.image.copy(); ghost.set_alpha(128)
                        screen.blit(ghost, (sc*SQ, sr*SQ))
                    else:
                        pygame.draw.circle(screen, d_col, (sc*SQ+40, sr*SQ+40), 30)
                    pygame.draw.rect(screen, d_col, (sc*SQ, sr*SQ, SQ, SQ), 2)
            else:
                if p.image: screen.blit(p.image, (p.c*SQ, p.r*SQ))
                else:
                    p_col = COLORS["white_pc"] if p.color == 'W' else COLORS["black_pc"]
                    pygame.draw.circle(screen, p_col, (p.c*SQ+40, p.r*SQ+40), 35)
            if p == selected:
                pygame.draw.rect(screen, COLORS["highlight"], (p.c*SQ, p.r*SQ, SQ, SQ), 4)

        if game_over: draw_win_screen(screen, winner)

        for event in pygame.event.get():
            if event.type == pygame.QUIT: return
            if not game_over and event.type == pygame.MOUSEBUTTONDOWN:
                c, r = event.pos[0]//SQ, event.pos[1]//SQ
                if c >= 8 or r >= 8: continue
                ghost = next((p for p in pieces if p.is_superposed and (r, c) in p.states), None)
                if selected and ghost and selected != ghost:
                    if selected.is_legal_move(r, c, pieces):
                        selected.entangled_with, ghost.entangled_with = ghost, selected
                        selected.superpose((selected.r, selected.c), (r, c))
                        selected, turn = None, ('B' if turn == 'W' else 'W')
                        fact_index += 1 
                    continue
                elif ghost: 
                    ghost.collapse()
                    fact_index += 1 
                    continue
                clicked = next((p for p in pieces if not p.is_superposed and p.r == r and p.c == c), None)
                if split_mode and selected:
                    if selected.is_legal_move(r, c, pieces):
                        selected.superpose((selected.r, selected.c), (r, c))
                        split_mode, selected, turn = False, None, ('B' if turn == 'W' else 'W')
                        fact_index += 1 
                elif clicked and clicked.color == turn: selected = clicked
                elif selected and selected.is_legal_move(r, c, pieces):
                    can_move = True
                    if selected.name != "N" and selected.path_blocked(r, c, pieces):
                        if selected.name in ["R", "B", "Q"] and random.random() < TUNNEL_CHANCE: pass
                        else: can_move = False
                    if can_move:
                        target = next((p for p in pieces if p.r == r and p.c == c), None)
                        if target:
                            if target.name == "K": winner, game_over = ("WHITE" if turn=='W' else "BLACK"), True
                            pieces.remove(target)
                        selected.move(r, c); selected, turn = None, ('B' if turn == 'W' else 'W')
                        fact_index += 1 
            if event.type == pygame.KEYDOWN and event.key == pygame.K_s and selected: split_mode = True
        pygame.display.flip()

if __name__ == "__main__": main()